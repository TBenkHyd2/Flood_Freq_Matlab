clc; close all;
% Flood Frequency Distribution  using  7 Probability Plots -- By  T. Benkaci & N.Dechemi* (ALgeria)
% Analyse Frequentielle des crues Avec 7 lois statistiques -- 
% Par T. % Benkaci & N.Dechemi (2018)
 %email: benkacitarik@yahoo.fr

% The file Data is : File_Data.txt
% then the data PP = File_Data.txt contains two columns ;
% D=PP(1:end,1:1);  is the Years : 1995-1996--- 2016- 2017
% P=PP(1:end,2:2) ;  the Observed Data i.e Annual Rainfall (Precipitations) (mm)
 % The Main file is:
Flood_Tarik

% Probability plots are:  
% Les lois de distribution statistiques sont: 
% 1- Loi Normale          ----  Normal Distribution              
% 2- Loi Log Normale      ----  Log Normal Distribution             
% 3- Loi de Gumbel        ----  Gumbel Distribution                
% 4- Loi General-Extre-Va ----  General Extreme Values Distribution (GEV) 
% 5- Loi GAMMA            ----  GAMMA Distribution (2P)            
% 6- Loi Log Pearson3     ----  Log Pearson 3 Distribution         
% 7- Loi Goodrich         ----  Goodrich Distribution            

% For Plot Position Formula  there is: --Pour le  Calcul des Fr�quences empiriques, il y a : 
% 1- Hazen Method  
% 2- Weibull Method     
% 3- Cunane Method  
% 4- Chegodayev Method   
% 5- Gringorten Method 

% The Method for Parameters Estimation is:
%Method of Moments
%Method of Weighted Moments.


%The Results are the Quantiles for differents Return Periods:
%5 10 20 50 100 500 1000 and 10000
%and plot Flood Frequency and plot the QQ-plot for probability Distribution

% The Results are saved in Results_Flood.txt')